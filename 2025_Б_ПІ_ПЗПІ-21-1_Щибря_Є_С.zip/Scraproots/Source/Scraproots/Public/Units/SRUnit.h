// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Actor.h"
#include "SRUnit.generated.h"

UCLASS()
class SCRAPROOTS_API ASRUnit : public AActor
{
	GENERATED_BODY()
};
